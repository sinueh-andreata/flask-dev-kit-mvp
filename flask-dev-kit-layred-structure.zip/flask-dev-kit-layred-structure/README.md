# flask-dev-kit
Dev kit para acelerar o desenvolvimento de sistemas web Flask, com boas práticas, arquitetura em camadas e segurança pré configurada
